
export type CodeType = 'html' | 'css' | 'js';

export interface CodeState {
  html: string;
  css: string;
  js: string;
}
